#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Provides variables for string and integer conversion."""


NOT_THE_QUESTION = 'The answer to life, the universe, and everything? It\'s '
ANSWER = 42

THANKS_FOR_THE_FISH = NOT_THE_QUESTION + str(ANSWER)
