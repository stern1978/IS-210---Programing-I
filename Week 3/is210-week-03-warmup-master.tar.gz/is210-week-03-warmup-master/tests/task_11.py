#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Task 11"""

ESCAPE_STRING = '\\' + "n'" + '"'
