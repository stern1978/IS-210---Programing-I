#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Task 12"""

from decimal import Decimal
from fractions import Fraction

INTVAL = 1

FLOATVAL = 0.1

DECVAL = Decimal('0.1')

FRACTVAL = Fraction(1, 10)
