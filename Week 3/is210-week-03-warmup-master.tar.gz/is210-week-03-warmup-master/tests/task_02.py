#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Mathmatical statements"""


WEEKS = (((10 % 19) + 100) + 2 ** 8) / 7
