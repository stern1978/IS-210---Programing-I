#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""A computer that can build the question.  For a moment, nothing happened.
   Then, after a second or so, nothing continued to happen."""

THE_ANSWER_TO_EVERYTHING = 42

INFINITE_IMPROBABILITY = 'browning motion'
