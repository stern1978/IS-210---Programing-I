#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Task 14"""

IS_TRUE = True

IS_FALSE = False

IS_NONE = None

INTIGER_EQUIV = IS_TRUE == 1 and IS_FALSE == 0
