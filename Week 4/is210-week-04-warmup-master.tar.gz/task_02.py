#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""This module does some pretty crazy math."""


import hamlet

POSITIONAL = hamlet.crazy_math(4, 100000, 8, 98)
